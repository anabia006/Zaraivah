const button = document.getElementById('ok');

button.addEventListener('click', function() {
  window.location.href = 'index.html';
});